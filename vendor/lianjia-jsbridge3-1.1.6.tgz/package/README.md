node v18.18.2 

发包

1. 修改package.json version
2. npm run prod
3. npm publish --tag  beta

[//]: # (4.  npm publish --tag=latest --registry=http://artifactory.intra.ke.com/artifactory/api/npm/npm-virtual/&#41;)

cdn 上线

青蝉

https://buddha.ke.com/micro-fe/feci/buddha/34648/jobs?service_id=3812

发布 

https://release.ke.com/env/projectShow?projectId=5811&source=keOnes&pid=162372
