export const getCookie = (sKey = "") => {
    if (!sKey) {
        return;
    }
    sKey = sKey.replace(/([\.\[\]\$])/g, "\\$1");
    let rep = new RegExp("(^| )" + sKey + "=([^;]*)?;", "ig");
    let co = document.cookie + ";";
    let res = rep.exec(co);
    let val = [];
    while (res) {
        val.push(res[2] || "");
        res = rep.exec(co);
    }
    return val;
};
export const setCookie = (
    name = "",
    value = "",
    cookieDomain = "",
    expiredays: any
) => {
    if (!name) {
        return;
    }
    let exdate = new Date();
    exdate.setDate(exdate.getDate() + expiredays);
    document.cookie =
        name +
        "=" +
        encodeURI(value) +
        (expiredays == null
            ? ""
            : ";path=/;domain=" + cookieDomain + ";expires=" + exdate.toUTCString());
};
export const getBase64Image = (src: string) => {
    return new Promise((resolve) => {
        let xhr = new XMLHttpRequest();
        xhr.open("get", src, true);
        xhr.responseType = "blob";
        xhr.onload = function () {
            if (this.status === 200) {
                let blob = this.response;
                let oFileReader = new FileReader();
                oFileReader.onloadend = function (e: any) {
                    const base64 = e.target.result;
                    resolve(base64);
                };
                oFileReader.readAsDataURL(blob);
            }
        };
        xhr.onerror = function () {
            resolve("");
        };
        xhr.send();
    });
};
export const getAPPEnv = () => {
    const ua = navigator.userAgent;
    const isZhuoMian = /Electron/gim.test(ua);
    const isLinkApp = /Link/gim.test(ua) && !isZhuoMian; //link
    const isDplus = /Alliance\/Dplus/gim.test(ua) && !isZhuoMian; // D+ 置业顾问
    const isDeyou = !isDplus && /Alliance/gim.test(ua) && !isZhuoMian; // A+和CA工作平台和21世纪
    const isBaichuan = /lianjiabaichuan/gim.test(ua) && !isZhuoMian; //百川
    const isBeike = /lianjiabeike/gim.test(ua); //贝壳
    const isVrstudio = /Link VRStudio/gim.test(ua); //vr
    const isDecorateHome = /Lianjia\/beikesteward/gim.test(ua); //装修HOME端
    const isDecorateCustom = /Lianjia\/decorate\/jinggong/gim.test(ua); //贝窝家装App
    const isDecorateDesigner = /Lianjia\/decorate\/jgdesigner/gim.test(ua); //贝窝设计App
    const isDecorateXinghai = /Lianjia\/decorate\/bktransport/gim.test(ua); // 家装星海App
    const isDecorateJingGongB = /Lianjia\/beikejinggong/gim.test(ua); //贝窝设计App
    const isZuFangApp = /Lianjia\/beike_rentplat/gim.test(ua); //贝壳租房
    const isZhidao = /zhidao/gim.test(ua); // 贝经堂独立app
    const isLiveInApp = /Lianjia\/LiveInBeike/gim.test(ua); // 贝壳LiveIn
    const isAnzhuApp = /Lianjia\/beikeanzhu/gim.test(ua); // 安住
    const isFanghuoji = /Lianjia\/fanghuoji/gim.test(ua); // 房火计

    const isLianjiaApp =
        !isLinkApp &&
        !isDplus &&
        !isDeyou &&
        !isBaichuan &&
        !isBeike &&
        !isZuFangApp &&
        !isDecorateHome &&
        !isDecorateCustom &&
        !isDecorateDesigner &&
        !isDecorateJingGongB &&
        !isZhidao &&
        !isLiveInApp &&
        !isAnzhuApp &&
        !isDecorateXinghai &&
        !isFanghuoji &&
        /Lianjia/gim.test(ua);
    const isApp =
        isLinkApp ||
        isDplus ||
        isDeyou ||
        isBaichuan ||
        isBeike ||
        isLianjiaApp ||
        isVrstudio ||
        isDecorateHome ||
        isDecorateCustom ||
        isDecorateDesigner ||
        isDecorateJingGongB ||
        isZuFangApp ||
        isZhidao ||
        isLiveInApp ||
        isAnzhuApp ||
        isDecorateXinghai ||
        isFanghuoji
    ;
    return {
        isLinkApp,
        isDplus,
        isDeyou,
        isBaichuan,
        isBeike,
        isLianjiaApp,
        isApp,
        isVrstudio,
        isDecorateHome,
        isDecorateCustom,
        isDecorateDesigner,
        isDecorateJingGongB,
        isZuFangApp,
        isZhidao,
        isLiveInApp,
        isAnzhuApp,
        isDecorateXinghai,
        isFanghuoji
    };
};
// 随机生成6位字符串,包含字母和数字
export const getUuid = (len = 6) => {
    let str = "";
    for (let i = 0; i < len; i++) {
        let ran = Math.floor(Math.random() * 10);
        str += ran;
    }
    return str;
};

export const versionCompare = (version1, operation, version2) => {
    if (!version1 || !version2 || !operation) throw new Error('miss param')
    version1 = version1.split('.')
    version2 = version2.split('.')
    let length = Math.max(version1.length, version2.length)
    let distance = 0
    for (let index = 0; index < length; index++) {
        distance = (version1[index] | 0) - (version2[index] | 0)
        if (distance !== 0) break
    }
    switch (operation) {
        case '<':
            return distance < 0
        case '<=':
            return distance <= 0
        case '==':
        case '===':
            return distance === 0
        case '>=':
            return distance >= 0
        case '>':
            return distance > 0
        case '!=':
        case '!==':
        case '<>':
            return distance !== 0
        default:
            throw new Error('operation "' + operation + '" is not allowed.')
    }
}

export const formatNavStyleParams = (options) => {
    options = options || {}
    const {
        navSty = '0',
        graBColor = 'FFFFFF',
        graHeight = '',
        graBTColor = 'FFFFFF',
        graETColor = '000000',
        graSLight = '1',
        sLight = '1',
        graSTHide = '1',
        light
    } = options ;
    let params: any = {
        navSty: navSty.toString(),
        graBColor,
        graHeight: graHeight.toString(),
        graBTColor,
        graSLight: graSLight.toString(),
        graETColor,
        graSTHide: graSTHide.toString(),
        sLight: sLight.toString()
    }

    if (navSty.toString() === '0' && typeof options.sLight === 'undefined') {
        params.sLight = '0'
    }
    if (navSty.toString() === '3') {
        const {endBgColor, startColor, endColor, height, hideTitle,} = options;
        params.graBColor = endBgColor || graBColor;
        params.graBTColor = startColor || graBTColor;
        params.graETColor = endColor || graETColor;
        params.graHeight = String(height || graHeight);
        params.graSTHide = String(hideTitle || graSTHide);
        params.graSLight = String(light || graSLight)
        params.sLight = String(light || sLight)
        if (params.graSLight === '-1') {
            delete params.graSLight;
        }
        if(params.sLight === '-1') {
            params.sLight = sLight || '1'
        }
    } else if (light) {
        params.sLight = String(light);
    }
    return params;
}
