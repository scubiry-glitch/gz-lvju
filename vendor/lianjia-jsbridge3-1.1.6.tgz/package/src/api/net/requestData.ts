/**
 * 请求数据
 */
import Base from "../../Base";
type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
// 请求头类型
type ContentType = "text/html" | "text/plain" | "multipart/form-data" | "application/json" | "application/x-www-form-urlencoded" | "application/octet-stream" | string;

// 请求头
type Headers = {
    "Content-Type"?: ContentType //  请求头类型
    [key: string]: any // 其他请求头
}
//  请求数据
type methodI =  "get" | "post" | string
type requestDataI = {
    url: string; // 请求地址
    method?: methodI; // 请求方法
    params?: object; // 请求参数
    headers?: Headers; // 请求头
    success?: (res: Result) => void; // 成功回调
    fail?: (res: Result) => void; //    失败回调
    timeout: number; // 超时时间
    [key: string]: any;
}
 const requestData = (options: requestDataI) => {
    const {
        url,
        method = "get",
        params = {},
        headers = {},
        success,
        fail,
        timeout,
    } = options;
     if (!url) {
         fail && fail({ errorCode: 1, msg: "url不能为空" });
         return;
     }
    Base.actionBridgeKey({
        name: "requestData",
        param: JSON.stringify({
            url,
            method,
            params,
            headers,
        }),
        timeout,
        success,
        fail,
    });
}

export default requestData
