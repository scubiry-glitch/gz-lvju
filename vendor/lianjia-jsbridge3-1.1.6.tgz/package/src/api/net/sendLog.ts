// 日志
export interface sendLogI {
    logLevel?: string // 日志等级（ LogLevelNormal： 1 、 LogLevelWarning： 2 、LogLevelError： 3 ）
    logType?: string // 业务方代码日志： 1 系统行为： 2, 基础库日志： 3 网络日志： 4）

    subType?: string // 日志标识,比如 “jsbridge”
    summary?: string
    detail?: any // 日志描述 object
}
const sendLog = (params: sendLogI) => {
    try {
        if (typeof window !== "object") {
            return;
        }
        let summary = "业务信息上报：";
        let detail = {};
        if (
            params &&
            params.summary &&
            (typeof params.summary).toLocaleString() === "string"
        ) {
            summary = params.summary;
        }
        if (
            params &&
            params.detail &&
            (typeof params.detail).toLocaleString() === "object"
        ) {
            try {
                detail = JSON.parse(JSON.stringify(params.detail));
            } catch (e) {
            }
            detail = params.detail;
        }
        const win = window as any;
        if (
            win.BKNativeLog &&
            win.BKNativeLog.log &&
            typeof win.BKNativeLog.log === "function"
        ) {
            win.BKNativeLog.log(
                JSON.stringify({
                    logLevel: params.logLevel || '1',
                    logType: params.logType || '1',
                    subType: params.subType ||  "customerBridge",
                    summary: summary,
                    params: detail,
                })
            );
        }
    } catch (e) {
        if ("console" in window) {
            console.log("window.BKNativeLog.log error", e);
        }
    }
}
export default sendLog
