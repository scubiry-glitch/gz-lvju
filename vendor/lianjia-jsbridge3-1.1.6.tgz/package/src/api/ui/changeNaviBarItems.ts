/**
 * 图片浏览器
 */
import Base from "../../Base";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}

type ButtonItem =  {
    imageUrl: string // 图片地址
    callback: string // 回掉函数名
    width?: number | string // 宽度
    height?: number |  string // 高度
}
type barTitleI = {
    title?: string //标题文字
    imageUrl?: string //标题图片
    imageWidth?: number | string // 图片宽度
    imageHeight?: number |  string  // 图片高度
}


type changeNaviBarItemsI = {
    leftButtons?: ButtonItem[] //左侧按钮
    rightButtons?: ButtonItem[] // 右侧按钮
    barTitle?: barTitleI //标题
    success?: (res: Result) => void; // 成功回调
    fail?: (res: Result) => void; //    失败回调
    [key: string]: any; // 其他参数
}

const changeNaviBarItems = (options: changeNaviBarItemsI) => {
    const {
        leftButtons,
        rightButtons,
        barTitle,
        success,
        fail,
    } = options;
    let param: any = {}
    if(Array.isArray(leftButtons)){
        param.leftButtons = leftButtons
    }
    if(Array.isArray(rightButtons)){
        param.rightButtons = rightButtons
    }
    if(barTitle && Object.keys(barTitle).length > 0){
        if(barTitle.title && typeof barTitle.title !== 'string'){
            barTitle.title = ''
        }
        if(barTitle.imageUrl && typeof barTitle.imageUrl !== 'string'){
            barTitle.imageUrl = ''
        }
        param.barTitle = barTitle
    }
    Base.actionBridgeKey({
        name: "changeNaviBarItems",
        param: JSON.stringify(param),
        success,
        fail,
    });
}
export default changeNaviBarItems
