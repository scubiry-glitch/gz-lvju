/**
 * 设置标题
 */
import Base from "../../Base";
type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
type setPageTitleI = {
    title: string // 页面标题
    success?: (res: Result) => void // 成功回调
    fail?: (res: Result) => void //  失败回调
    [key: string]: any
}
const setPageTitle = (options: string | setPageTitleI) => {
    let title = typeof options === 'string' && options || ''
    let success, fail
    if(typeof options === 'object'){
        title = options.title
        if(typeof options.success !== 'undefined'){
            success = options.success
        }
        if(typeof options.fail !== 'undefined'){
            fail = options.fail
        }
    }
    Base.actionBridge2Key({
        name: "setPageTitle",
        param: title,
        success,
        fail,
    });
}

export default setPageTitle
