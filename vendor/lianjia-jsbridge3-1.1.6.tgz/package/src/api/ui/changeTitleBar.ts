/**
 * 设置标题字|颜色|导航色
 */
import Base from "../../Base";
type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
type changeTitleBarI = {
    name: string // 标题字
    textColor?: string //文案颜色
    backgroundColor?: string //背景颜色
    success?: (res: Result) => void // 成功回调
    fail?: (res: Result) => void //  失败回调
    [key: string]: any
}
const changeTitleBar = (options: changeTitleBarI) => {
    const { name, textColor = '#ffffff',backgroundColor ='#3072F6', success, fail } = options;
    Base.actionBridge2Key({
        name: "changeTitleBar",
        param: JSON.stringify({
            name,
            textColor,
            backgroundColor
        }),
        success,
        fail,
    });
}

export default changeTitleBar
