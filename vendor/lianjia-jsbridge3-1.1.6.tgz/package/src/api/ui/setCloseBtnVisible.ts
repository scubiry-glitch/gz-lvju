/**
 * 设置标题
 */
import Base from "../../Base";
type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
type setCloseBtnVisibleI = {
    visible: 0 | 1  // 是否可见
    success?: (res: Result) => void // 成功回调
    fail?: (res: Result) => void //  失败回调
    [key: string]: any
}
const setCloseBtnVisible = (options: setCloseBtnVisibleI) => {
    const { visible = 0, success, fail } = options;
    const time = new Date().getTime()
    const functionName: any = `_BKBridgeV2_setCloseBtnVisible_${time}`;
    if(typeof success === 'function'){
        (window as any)[functionName] = (resp) => {
            delete window[functionName]
            try {
                resp = JSON.parse(resp);
                if (resp.errorCode === "0" || resp.errorCode === 0 || resp.errorCode === "200" || resp.errorCode === 200) {
                    success && success(resp);
                } else {
                    fail && fail(resp);
                }
            } catch (e) {
                if ("console" in window) {
                    console.log("解析错误", e);
                }
                fail && fail({errorCode: 8, msg: "解析错误"});
            }
        }
    }
    Base.actionBridge2Key({
        name: "setCloseBtnVisible",
        param: JSON.stringify({
            visible,
            callback: functionName
        }),
        success,
        fail,
    });
}

export default setCloseBtnVisible
