/**
 * 设置右上角按钮
 */
import Base from "../../Base";
type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
type RightButtonItem = {
    name?:string // 名称
    clickUrl?: string // 点击执行schame地址(不传则只掉用callBackFunction )
    imageUrl?: string // 图片地址 或 端内定义的分享图片
    textHexColor?: string // 字体颜色
    callBackFunction?: string // 点击操作前置方法名称
    [key: string]: any
}
type setRightButtonI = {
    buttons: RightButtonItem[]
    success?: (res: Result) => void // 成功回调
    fail?: (res: Result) => void //  失败回调
    [key: string]: any
}
const setRightButton = (options: setRightButtonI) => {
    const { success, fail, buttons = [] } = options;
    if(typeof window !== 'object'){
        return
    }
    let name = 'setRightButton'
    if(window['HybridBridgeLJ']){
        name = 'setRightButton2'
    }
    const withToken = /Auth/img.test(navigator.userAgent)
    if(withToken){
        name = 'setRightButtonToken'
    }
    Base.actionBridge2Key({
        name: name,
        param: JSON.stringify(buttons),
        withToken,
        success,
        fail
    });
}

export default setRightButton
