/**
 * 设置标题栏按钮
 */
import Base from "../../Base";
import {getUuid} from "../../utils";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
type IBarItems =  {
    icon: string //图片（https开头）或者文字
    key: string, //当前调用时的唯一值，不能重复。
    callback?: string // 回掉函数名
    width?: number  // 宽度
    height?: number  // 高度
}
type IPosition = "left" | "right" | "center" | ""
type IBarTitle = {
    icon: string | string[] //图片（https开头）或者文字
    position?: IPosition | IPosition[], // left | right | center
    type?: string
    callback?: string // 回掉函数名
}

type IBarTitleStartEnd = {
    start: {
        icon: string //图片（https开头）或者文字
        position?: IPosition
        type?: string
        callback?: string // 回掉函数名
    }
    end: {
        icon: string //图片（https开头）或者文字
        position?: IPosition // left | right | center
        type?: string
        callback?: string // 回掉函数名
    }
}
type IButtonItem =  {
    start: IBarItems[]
    end: IBarItems[]
}


type ISetNavItems = {
    leftButtons?: IButtonItem | IBarItems[]      //左侧按钮
    rightButtons?: IButtonItem | IBarItems[]  // 右侧按钮
    barTitle?: IBarTitle | IBarTitleStartEnd //标题
    success?: (res: Result) => void; // 成功回调
    fail?: (res: Result) => void; //    失败回调
    changeCallback?: (status: "start" | "end" | string) => void; //    失败回调
    [key: string]: any; // 其他参数
}
const FormatItems = (items = [], functionName: string) : IBarItems[] => {
    return items.map((item, index) => ({
        key: item.key || `${functionName}${index}`,
        icon: item.icon || '',
        ...item,
    }));
}
const formatButtons = (buttons: IButtonItem | IBarItems[], position: string, fail: (res: Result) => void): { start: IBarItems[], end: IBarItems[] } | null => {
    if (Array.isArray(buttons)) {
        return {
            start: FormatItems(buttons, `${position}_start`),
            end: FormatItems(buttons, `${position}_end`)
        };
    } else if (buttons && Array.isArray(buttons.start) && Array.isArray(buttons.end)) {
        return {
            start: FormatItems(buttons.start, `${position}_start`),
            end: FormatItems(buttons.end, `${position}_end`)
        };
    } else {
        console.error(`${position}Buttons参数错误`);
        fail && fail({ errorCode: -1, msg: "设置错误" });
        return null;
    }
};
const setNavItems = (options: ISetNavItems) => {
    const {
        leftButtons,
        rightButtons,
        barTitle,
        success,
        fail,
        changeCallback,
    } = options;
    let param: any = {}
    if (leftButtons) {
        const formattedLeftButtons = formatButtons(leftButtons, 'left', fail);
        if (!formattedLeftButtons) return;
        param.leftButtons = formattedLeftButtons;
    }

    if (rightButtons) {
        const formattedRightButtons = formatButtons(rightButtons, 'right', fail);
        if (!formattedRightButtons) return;
        param.rightButtons = formattedRightButtons;
    }

    if(barTitle && Object.keys(barTitle).length > 0){
        let title: any = barTitle
        const hasIcon = 'icon' in title;
        const hasStartAndEnd = 'start' in title && 'end' in title;
        if(!(hasIcon || hasStartAndEnd)){
            console.error('barTitle参数错误, barTitle必须有icon字段或同时有start和end')
            fail && fail({errorCode: -1, msg: "设置错误"});
            return;
        }
        let startTitle: IBarTitle = {icon: '', position: 'center'};
        let endTitle: IBarTitle = {icon: '', position: 'center'};

        // 处理icon, position, type
        ['icon', 'position', 'type', 'callback'].forEach(attr => {
            if (title.hasOwnProperty(attr)) {
                if (Array.isArray(title[attr])) {
                    startTitle[attr] = title[attr][0] || '';
                    endTitle[attr] = title[attr][1] || title[attr][0] || '';
                } else if (typeof title[attr] === 'string') {
                    startTitle[attr] = title[attr];
                    endTitle[attr] = title[attr];
                }
            }
        });

        if (title.start && title.end) {
            startTitle = {...startTitle, ...title.start};
            endTitle = {...endTitle, ...title.end};
        }
        param.barTitle = {start: startTitle, end: endTitle};
    }
    if(changeCallback){
        const uuid = getUuid()
        const time = new Date().getTime()
        const functionName: any = `_BKBridgeV3_changeCallback_${time}_${uuid}`;
        (window as any)[functionName] = (resp: string) => {
            changeCallback(resp);
        };

    }
    Base.actionBridgeKey({
        name: "setNavItems",
        param: JSON.stringify(param),
        success,
        fail,
    })

}
export default setNavItems




