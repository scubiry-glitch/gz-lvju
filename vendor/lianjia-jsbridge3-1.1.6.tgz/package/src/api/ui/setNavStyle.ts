/**
 * 设置标题
 */
import Base from "../../Base";
import {formatNavStyleParams} from "../../utils";

export enum NavStyEnum {
    default = '0',
    hiddenNavBar = '1',
    hiddenBar = '2',
    Immersive = '3',
}

export enum graSLightEnum {
    black = '0',
    white = '1',
    off = '-1'
}

export enum sLightEnum {
    black = '0',
    white = '1'
}
export enum graSTHideEnum {
    hide = '1',
    show = '0'
}

// 0，bar不改变，1，隐藏navbar，2，隐藏bar，3 沉浸式bar。
type NavSty = 0 | 1 | 2 | 3 | '0' | '1' | '2' | '3' | NavStyEnum
//statusbar的开始是否是白色模式，如果开始是白色，那么最大高度就是黑色，反之亦然。
type IgraSLight = -1 | 0 | 1 | '-1' | '0' | '1' | graSLightEnum
// 时间，电量的颜色 1为白色，0为黑色
type IsLight = 0 | 1 | '0' | '1' | sLightEnum | string
// 开始的时候 title要不要显示 ，1表示不显示，0表示显示 有默认值，默认值是1,
type graSTHide = 0 | 1 | '0' | '1' | graSTHideEnum | string
type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
type ISetNavStyle = {
    navSty: NavSty // 0，bar不改变，1，隐藏navbar，2，隐藏bar，3 沉浸式bar。
    graBColor?: string //bar的滑动最大高度时的颜色
    graHeight?: number | string  //bar的滑动最大距离，可空，默认为状态栏和顶部bar的和
    graBTColor?: string //bar按钮和title的起始颜色
    graETColor?: string //bar按钮和title的滑动到最大高度的颜色
    graSLight?: IgraSLight  //statusbar的开始是否是白色模式，如果开始是白色，那么最大高度就是黑色，反之亦然。
    graSTHide?: graSTHide //开始的时候 title要不要显示 ，1表示不显示，0表示显示 有默认值，默认值是1,
    sLight?: IsLight // 时间，电量的颜色 1为白色，0为黑色

    endBgColor?: string //bar的滑动最大高度时的颜色
    height?: number | string //bar的滑动最大高度时的颜色
    startColor?: string //bar按钮和title的起始颜色
    endColor?: string //bar按钮和title的滑动到最大高度的颜色
    light?: IgraSLight  //statusbar的开始是否是白色模式，如果开始是白色，那么最大高度就是黑色，反之亦然。
    hideTitle?: graSTHide //开始的时候 title要不要显示 ，1表示不显示，0表示显示 有默认值，默认值是1,

    success?: (res: Result) => void // 成功回调
    fail?: (res: Result) => void //   失败回调
    [key: string]: any
}


const setNavStyle = (options: ISetNavStyle) => {
    const { success, fail } = options;
    const params = formatNavStyleParams(options)
    Base.actionBridgeKey({
        name: "setNavStyle",
        param: JSON.stringify(params),
        success,
        fail,
    });
}
export default setNavStyle
