/**
 * 退出监听
 */
import Base from "../../Base";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: any // 返回的额外参数
}
type IListenerType = 'btnClose' | 'btnReturn' | 'swipeBack'

type IListenExit = {
    h5Exit?: boolean  // 间隔时间
    listenerFun: string; // 监听回调
    type?: IListenerType[]; // 监听类型
    success?: (res: Result) => void; // 成功回调
    fail?: (res: Result) => void; //    失败回调
    [key: string]: any; // 其他参数
}
export const startListenExit = (options: IListenExit) => {
    const { h5Exit = true, listenerFun, success, fail, type } = options;
    let listenerType = ['btnClose', 'btnReturn', 'swipeBack'];
    if(type && Array.isArray(type) && type.length > 0){
        listenerType = type;
    }
    Base.actionBridgeKey({
        name: "startListenExit",
        param: JSON.stringify({
            h5Exit,
            listenerFun,
            type: listenerType.join(',')
        }),
        success,
        fail,
    });
}
export const stopListenExit = (options: { success?: (res: Result) => void; fail?: (res: Result) => void; } = {}) => {
    const { success, fail } = options;
    Base.actionBridgeKey({
        name: "stopListenExit",
        param: '',
        success,
        fail,
    });
}

export default {
    startListenExit,
    stopListenExit
}
