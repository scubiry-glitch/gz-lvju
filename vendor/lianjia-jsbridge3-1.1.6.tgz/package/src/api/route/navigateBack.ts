/**
 * 后退
 */
import Base from "../../Base";
import { getAppVersion } from "../base/init";
import { getAPPEnv, versionCompare } from "../../utils";
type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
type closeToI = {
    topTo: number // topTo 为一个负数，表示回到当前容器所在native堆栈中的那个页面，-1表示前一个页面，-2表示前两个页面
    secondTo: number // secondTo小于等于零，表示在topTo的基础上，还需要再在回到的目标容器的的那个页面，-1表示在目标容器中回退一个页面。0表示不会退
    success?: (res: Result) => void // 成功回调
    fail?: (res: Result) => void //  失败回调
    [key: string]: any
}
const navigateBack = (options: closeToI) => {
    const { topTo, secondTo, success, fail} = options;
    const version = getAppVersion()
    const appEnv = getAPPEnv()
    const isSupportKe = appEnv.isBeike && versionCompare(version, '>', '3.00.30')
    const isSupportLianjia = appEnv.isLianjiaApp && versionCompare(version, '>', '9.80.90')
    const isSupportBApp = !appEnv.isBeike && !appEnv.isLianjiaApp && versionCompare(version, '>', '6.10.0')
    if (isSupportKe || isSupportLianjia || isSupportBApp || appEnv.isAnzhuApp  || appEnv.isDecorateXinghai || appEnv.isFanghuoji) {
        Base.actionBridgeKey({
            name: 'closeTo',
            param: JSON.stringify({
                topTo,
                secondTo,
            }),
            success,
            fail,
        });
    } else {
        Base.actionBridge2Key({
            name: 'closeWeb',
            param: '拜拜',
            success,
            fail,
        });
    }
}

export default navigateBack
