/**
 * 保留当前webview，跳转到应用内的某个页面
 */
import Base from "../../Base";
import { getAppVersion, getSchemeLink } from "../base/init";
import { getAPPEnv, versionCompare } from "../../utils";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
export type openUrlI = {
    url: string // 要打开的url
    success?: (res: Result) => void // 成功回调
    fail?: (res: Result) => void //  失败回调
    forceUseOld?: boolean
    [key: string]: any
}
const navigateTo = (options: openUrlI) => {
    const { url = "", success, fail, forceUseOld = false } = options;
    let newUrl = url
    if (!url) {
        fail && fail({errorCode: 1, msg: "url不能为空"});
        return;
    }
    let name = 'actionWithUrl'
    let withToken = /Auth/img.test(navigator.userAgent)
    const version = getAppVersion()
    const appEnv = getAPPEnv()
    const isSupportKe = appEnv.isBeike && versionCompare(version, '>=', '3.01.10')
    const isSupportLianjia = appEnv.isLianjiaApp && versionCompare(version, '>=', '9.81.80')
    if (withToken) {
        name = 'actionWithUrlToken'
    }
    const isSupportBApp = !appEnv.isBeike && !appEnv.isLianjiaApp && versionCompare(version, '>', '6.21.0')
    if (!forceUseOld && (isSupportKe || isSupportLianjia || isSupportBApp || appEnv.isAnzhuApp || appEnv.isDecorateXinghai || appEnv.isFanghuoji)) {
        if (!/:\/\//.test(newUrl)) {
            newUrl = getSchemeLink(newUrl)
        }
        Base.actionBridgeKey({
            name: 'openUrl',
            param: JSON.stringify({
                url: newUrl,
                isReplace: 0
            }),
            withToken,
            success,
            fail,
        });
        return;
    } else {
        if (/^http(s)?:\/\//.test(newUrl)) {
            if (appEnv.isBeike || appEnv.isLianjiaApp || appEnv.isAnzhuApp) {
                newUrl = getSchemeLink(`web/main?url=${encodeURIComponent(url)}`)
            } else {
                newUrl = getSchemeLink(`web/compaign?htmlurlstring=${encodeURIComponent(url)}`)
            }
        }
        if (!/:\/\//.test(newUrl)) {
            newUrl = getSchemeLink(newUrl)
        }
        Base.actionBridge2Key({
            name,
            param: newUrl,
            withToken,
            success,
            fail,
        });
    }
}
export default navigateTo
