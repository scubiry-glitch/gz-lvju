/**
 * 选择图片
 */
import Base from "../../Base";
type Result  = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
// 请求头类型
type ContentType = "text/html" | "text/plain" | "multipart/form-data" | "application/json" | "application/x-www-form-urlencoded" | "application/octet-stream" | string;
// 请求头
type Headers = {
    "Content-Type"?: ContentType //  请求头类型
    [key: string]: any // 其他请求头
}
// 选择图片
type chooseImageI = {
    count?: number; //  最大选择数量
    accept?: 'image/*' | 'video/*' | 'audio/*' | string; // 选择图片类型
    action: string; // 选择图片类型
    confirmText?: string; // 确认按钮文字
    headers?: Headers; // 请求头
    success?: (res: Result) => void; // 成功回调
    fail?: (res: Result) => void; // 失败回调
    sourceType?: 'album' | 'camera' // 选择图片的来源(album从相册选图 camera	使用相机)
    saveAlbum?: 0 | 1 // 是否拍照后存储相册
    allowOriginPhoto?: boolean // 是否显示允许选择原图，true就是上传原图， false 就是原图如果过大 会压缩上传
    [key: string]: any; // 其他参数
}
const chooseImage = (options: chooseImageI) => {
    const {
        count = 1,
        accept = "",
        action = "",
        confirmText = "确认",
        headers = {},
        sourceType = 'album',
        saveAlbum = 1,
        allowOriginPhoto = true,
        success,
        fail,
    } = options;
    if (!action) {
        fail && fail({ errorCode: 1, msg: "action不能为空" });
        return;
    }
    if(sourceType === 'album'){
        Base.actionBridgeKey({
            name: "photoPicker",
            param: JSON.stringify({ count, accept, action, headers, confirmText, allowOriginPhoto }),
            success,
            fail,
        });
    } else {
        Base.actionBridgeKey({
            name: "takePhoto",
            param: JSON.stringify({ accept, action, headers, saveAlbum }),
            success,
            fail,
        });
    }
}
export default chooseImage
