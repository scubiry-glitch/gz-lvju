/**
 * 保存图片
 */
import Base from "../../Base";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}

type saveImageI = {
    image: string //下载链接 | base64
    success?: (res: Result) => void; // 成功回调 完成后callBackName回调
    fail?: (res: Result) => void; //    失败回调
    [key: string]: any; // 其他参数
}

const saveImage = (options: saveImageI) => {
    const { image, success, fail } = options;
    if(!image){
        fail && fail({ errorCode: 1, msg: "图片信息不能为空" });
        return
    }
    let name = /^data/.test(image) ? 'saveImage' : 'saveImageUrl'
    Base.actionBridge2Key({
        name,
        param: image,
        success,
        fail,
    });
}
export default saveImage
