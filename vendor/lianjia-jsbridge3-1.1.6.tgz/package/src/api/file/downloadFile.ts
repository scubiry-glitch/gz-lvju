/**
 * 下载文件
 */
import Base from "../../Base";

type Result  = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
type downloadFileI =  {
    url: string //下载链接
    isShowShare?: 0 | 1 //1表示分享，0表示不分享
    md5?: string
    shareName?: string
    progressCallBack?: string // window方法名 进度回掉信息
    success?: (res: Result) => void; // 成功回调 完成后callBackName回调
    fail?: (res: Result) => void; //    失败回调
    [key: string]: any; // 其他参数
}

const downloadFile = (options: downloadFileI) => {
    const { url, isShowShare = 0, progressCallBack = '', md5 = '' , shareName = '', success, fail } = options;
    if(!url){
        fail && fail({ errorCode: 1, msg: "url不能为空" });
        return
    }
    let param: any = {
        url,
        isShowShare,
        md5,
        shareName
    }
    if(progressCallBack){
        param.progressCallBack = progressCallBack
    }
    Base.actionBridgeKey({
        name: "downloadFile",
        param: JSON.stringify(param),
        success,
        fail,
    });
}
export default downloadFile
