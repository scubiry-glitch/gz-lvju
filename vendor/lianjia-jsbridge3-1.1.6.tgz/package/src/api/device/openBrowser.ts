/**
 * 设置标题
 */
import Base from "../../Base";
type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
type openBrowserI = {
    url: string // 页面标题
    success?: (res: Result) => void // 成功回调
    fail?: (res: Result) => void //  失败回调
    [key: string]: any
}
const openBrowser = (options: string | openBrowserI) => {
    let url = typeof options === 'string' && options || ''
    let success, fail
    if(typeof options === 'object'){
        url = options.url
        if(typeof options.success !== 'undefined'){
            success = options.success
        }
        if(typeof options.fail !== 'undefined'){
            fail = options.fail
        }
    }
    Base.actionBridge2Key({
        name: "openBrowser",
        param: url,
        success,
        fail,
    });
}

export default openBrowser
