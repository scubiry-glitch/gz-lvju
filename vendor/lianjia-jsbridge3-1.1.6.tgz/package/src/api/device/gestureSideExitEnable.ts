/**
 * 支持屏幕横竖屏切换
 */
import Base from "../../Base";

type Result =  { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
export enum ExitEnable {
    unenable = '0',
    enable = '1'
}

interface gestureSideExitEnableI {
    enable:  '0' | '1' | ExitEnable //  0,右滑退出webview;  1,不能右滑退出webview
    success?: (res: Result) => void // 成功回调
    fail?: (res: Result) => void //  失败回调
    [key: string]: any
}

const gestureSideExitEnable = (options: gestureSideExitEnableI) => {
    const { enable = '1', success, fail } = options;
    Base.actionBridge2Key({
        name: "gestureSideExitEnable",
        param: enable,
        success,
        fail,
    });
}

export default gestureSideExitEnable
