/**
 * 跳转设置wifi
 */
import Base from "../../Base";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}

type changeWifiStatusI = {
    success?: (res: Result) => void // 成功回调
    fail?: (res: Result) => void //  失败回调
    [key: string]: any
}

const changeWifiStatus = (options: changeWifiStatusI) => {
    const { success, fail } = options;
    Base.actionBridge2Key({
        name: "changeWifiStatus",
        param: '',
        success,
        fail,
    });
}

export default changeWifiStatus
