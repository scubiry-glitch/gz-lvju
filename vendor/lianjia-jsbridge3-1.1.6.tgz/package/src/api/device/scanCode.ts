/**
 * 扫码
 */
import Base from "../../Base";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
type scanCodeI = {
    success?: (res: Result) => void; // 成功回调
    fail?: (res: Result) => void; //   失败回调
    onlyScanCode?: boolean; // 是否只扫码
    [key: string]: any;
}
// 扫码
const scanCode = (options?: scanCodeI) => {
    const { success, fail, onlyScanCode = false } = options || {};
    Base.actionBridgeKey({
        name: "scanCode",
        param: JSON.stringify({
            onlyScanCode
        }),
        success,
        fail,
    });
}
export default scanCode
