/**
 * 传感器
 */
import Base from "../../Base";
type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
type setSensorCallbackI = {
    sensor_type: "shake"
    jsFunction: string // 端上回调的方法
    success?: (res: Result) => void // 成功回调
    fail?: (res: Result) => void //  失败回调
    [key: string]: any
}
const setSensorCallback = (options: setSensorCallbackI) => {
    const { sensor_type = 'shake', jsFunction, success, fail } = options;
    Base.actionBridge2Key({
        name: "setSensorCallback",
        param: JSON.stringify({
            sensor_type,
            jsFunction
        }),
        success,
        fail,
    });
}

export default setSensorCallback
