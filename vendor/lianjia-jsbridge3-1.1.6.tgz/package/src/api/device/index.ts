import appStorge from "./appStorge";
import changeOrientation from "./changeOrientation";
import gestureSideExitEnable from "./gestureSideExitEnable";
import launchPhoneCall from "./launchPhoneCall";
import location from "./location";
import scanCode from "./scanCode";
import {screenshot, StartScreenshot, registerScreenShotMonitor, unRegisterScreenShotMonitor } from "./screenshot";
import setSensorCallback from "./setSensorCallback";
import vibrate from "./vibrate";
import changeWifiStatus from "./changeWifiStatus";
import sendTextMessage from "./sendTextMessage";
import openBrowser from "./openBrowser";
import makePhoneCall from "./makePhoneCall";
import { startListenGyroscope, stopListenGyroscope } from "./gyroscope";
import { startListenDeviceMotion, stopListenDeviceMotion } from "./listenDeviceMotion";
export {
    appStorge,
    changeOrientation,
    gestureSideExitEnable,
    launchPhoneCall,
    location,
    scanCode,
    setSensorCallback,
    vibrate,
    screenshot,
    StartScreenshot,
    registerScreenShotMonitor,
    unRegisterScreenShotMonitor,
    changeWifiStatus,
    sendTextMessage,
    openBrowser,
    makePhoneCall,
    startListenGyroscope,
    stopListenGyroscope,
    startListenDeviceMotion,
    stopListenDeviceMotion
}
