/**
 * 支持屏幕横竖屏切换
 */
import Base from "../../Base";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
export enum Orientation {
    vertical = '1',
    Landscape = '0'
}
type changeOrientationI = {
    orientation:  '0' | '1' | Orientation //  0,横屏;  1,竖屏
    success?: (res: Result) => void // 成功回调
    fail?: (res: Result) => void //  失败回调
    [key: string]: any
}

const changeOrientation = (options: changeOrientationI) => {
    const { orientation = '1', success, fail } = options;
    Base.actionBridge2Key({
        name: "changeOrientation",
        param: orientation,
        success,
        fail,
    });
}

export default changeOrientation
