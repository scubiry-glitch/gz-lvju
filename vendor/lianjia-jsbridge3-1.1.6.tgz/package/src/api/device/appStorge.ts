/**
 * 共享存储
 */
import Base from "../../Base";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: any // 返回的额外参数
}
// 0 内存存储，临时性的，
// 1 硬盘存储，永久性的。除非删除App
export enum storeTypeI {
    Memory = 0,
    Disk = 1
}
// 0 共享存储，所有的人都使用该存储，不区分域名。
// 1 私有存储，只有统一域名可以访问，精确到子域名。
export enum secureTypeI{
    share = 0,
    Private = 1
}
type storgeI = {
    storeType?: 0 | 1 | storeTypeI
    secureType?:  0 | 1 | secureTypeI
    success?: (res: Result) => void; // 成功回调
    fail?: (res: Result) => void; //    失败回调
    [key: string]: any; // 其他参数
}
const appStorge =  {
    set: (key: string, value: any, options: storgeI = {})=> {
        const { storeType = 0, secureType = 0, success, fail } = options
        if(!key){
            fail && fail({ errorCode: 1, msg: "key不能为空" });
            return
        }
        value = value || ''
        try {
            if(value && typeof value !== 'string'){
                value = JSON.stringify(value)
            }
            value = encodeURIComponent(value)
        } catch (e) {
            fail && fail({ errorCode: 2, msg: "value encode失败" });
            return
        }
        Base.actionBridgeKey({
            name: "appStorge",
            param: JSON.stringify({
                key,
                value,
                type: 'save',
                storeType,
                secureType,
            }),
            success,
            fail,
        });
    },
    remove: (key: string, options: storgeI = {})=> {
        const { storeType = 0, secureType = 0, success, fail } = options
        if(!key){
            fail && fail({ errorCode: 1, msg: "key不能为空" });
            return
        }
        Base.actionBridgeKey({
            name: "appStorge",
            param: JSON.stringify({
                key, type: 'remove', storeType, secureType,
            }),
            success,
            fail,
        });
    },
    get: (key: string, options: storgeI = {})=>{
        const { secureType = 0, storeType = 0, success, fail } = options
        if(!key){
            fail && fail({ errorCode: 1, msg: "key不能为空" });
            return
        }
        options.success = (res: any) => {
            if (res && res.extraParam && res.extraParam.value) {
                try {
                    res.extraParam.value = decodeURIComponent(res.extraParam.value);
                    try {
                        res.extraParam.value = JSON.parse(res.extraParam.value);
                    } catch (e) {
                        console.warn(e);
                    }
                } catch (e) {
                    console.warn(e);
                }
            }
            success && success(res);
        }
        Base.actionBridgeKey({
            name: "appStorge",
            param: JSON.stringify({
                type: 'get',
                key,
                secureType,
                storeType
            }),
            success: options.success,
            fail,
        });
    }

}


export default appStorge
