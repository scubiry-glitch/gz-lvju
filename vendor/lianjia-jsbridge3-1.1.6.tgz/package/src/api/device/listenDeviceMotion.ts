/**
 * 监听设备放置变化
 */
import Base from "../../Base";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: any // 返回的额外参数
}
export enum IIntervalType {
    FASTEST = 1,
    GAME = 2,
    DELAY_UI = 3,
    NORMAL = 4
}

type IStartListenDeviceMotion = {
    intervalType?: 1 | 2 | 3 | 4 | '1' |'2' | '3' | '4' | IIntervalType // 间隔时间
    listenerFun: string; // 监听回调
    success?: (res: Result) => void; // 成功回调
    fail?: (res: Result) => void; //    失败回调
    [key: string]: any; // 其他参数
}
export const startListenDeviceMotion = (options: IStartListenDeviceMotion) => {
    const { intervalType = 3, listenerFun, success, fail } = options;
    Base.actionBridgeKey({
        name: "startListenDeviceMotion",
        param: JSON.stringify({
            interval: intervalType,
            listenerFun,
        }),
        success,
        fail,
    });
}
export const stopListenDeviceMotion = (options: { success?: (res: Result) => void; fail?: (res: Result) => void; }) => {
    const { success, fail } = options;
    Base.actionBridgeKey({
        name: "stopListenDeviceMotion",
        param: '',
        success,
        fail,
    });
}

export default {
    startListenDeviceMotion,
    stopListenDeviceMotion
}
