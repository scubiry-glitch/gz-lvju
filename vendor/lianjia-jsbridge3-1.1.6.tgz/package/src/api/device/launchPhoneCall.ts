/**
 * 唤起打电话页面,并带上电话号码，不自动拨号
 */
import Base from "../../Base";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}

type launchPhoneCallI = {
    phoneNumber: string //电话号码
    success?: (res: Result) => void; // 成功回调 完成后callBackName回调
    fail?: (res: Result) => void; //    失败回调
    [key: string]: any; // 其他参数
}

const launchPhoneCall = (options: launchPhoneCallI) => {
    const { phoneNumber, success, fail } = options;
    if(!phoneNumber){
        fail && fail({ errorCode: 1, msg: "号码不能为空" });
        return
    }
    Base.actionBridgeKey({
        name: 'launchPhoneCall',
        param: phoneNumber,
        success,
        fail,
    });
}
export default launchPhoneCall
