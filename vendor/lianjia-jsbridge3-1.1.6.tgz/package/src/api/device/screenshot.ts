/**
 * 截图
 */
import Base from "../../Base";
type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}
// url或(startLeft/startTop/width/height)
type screenshotI = {
    startLeft?: number //截图左上定点的坐标x
    startTop?: number //截图左上定点的坐标y
    width?: number  //截图的宽度
    height?: number //截图的高度
    success?: (res: Result) => void // 成功回调
    fail?: (res: Result) => void //  失败回调
    [key: string]: any
}
interface screenshotNewViewI {
    url?: string  //新开webview，截屏
    success?: (res: Result) => void // 成功回调
    fail?: (res: Result) => void //  失败回调
}
interface MonitorI {
    callback?: string
    success?: (res: Result) => void // 成功回调
    fail?: (res: Result) => void //  失败回调
}
export const screenshot = (options: screenshotI & screenshotNewViewI = {} ) => {
    const { url, startLeft = 0 , startTop = 0, width = 0, height = 0, success, fail} = options;
    let params:any = {}
    let name = 'screenshot'
    if(url){
        name = 'signalStartScreenshot'
        params.url = url
    } else if(startLeft || startTop || width || height){
        params = {
            startOffset: { x: startLeft, y: startTop },
            width,
            height,
        }
    }
    Base.actionBridgeKey({
        name,
        param: JSON.stringify(params),
        success,
        fail,
    });
}
export const StartScreenshot = (options: screenshotI = {})=> {
    const { startLeft = 0 , startTop = 0, width = 0, height = 0, success, fail} = options;
    let params:any = {}
    if(startLeft || startTop || width || height){
        params = {
            startOffset: { x: startLeft, y: startTop },
            width,
            height,
        }
    }
    Base.actionBridgeKey({
        name: "signalRealScreenshot",
        param: JSON.stringify(params),
        success,
        fail,
    });
}
export const registerScreenShotMonitor = (options: MonitorI )=> {
    const { callback, success, fail} = options;
    if(!callback){
        fail && fail({ errorCode: 1, msg: "回掉函数名不能为空" })
        console.error('请输入回掉函数名')
        return
    }
    Base.actionBridge2Key({
        name: "registerScreenShotMonitor",
        param: JSON.stringify({
            callback
        }),
        success,
        fail,
    });
}
export const unRegisterScreenShotMonitor = (options: MonitorI )=> {
    const { callback, success, fail} = options;
    if(!callback){
        fail && fail({ errorCode: 1, msg: "回掉函数名不能为空" });
        console.error('请输入回掉函数名')
        return
    }
    Base.actionBridge2Key({
        name: "unRegisterScreenShotMonitor",
        param: JSON.stringify({
            callback
        }),
        success,
        fail,
    });
}
