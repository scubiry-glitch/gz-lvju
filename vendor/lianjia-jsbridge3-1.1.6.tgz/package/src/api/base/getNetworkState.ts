import Base from "../../Base";
import { getNetwork } from "./init";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: "WIFI" | "WWAN" | "NOTREACH" | "UNKNOW" | unknown // 返回的额外参数
    resultFrom?: string // 返回的信息来源
}

type IGetNetworkState = {
    success?: (res: Result) => void; // 成功回调
    fail?: (res: Result) => void; //   失败回调
    [key: string]: any;
}
const getNetworkState = (options?: IGetNetworkState) => {
    const { success, fail } = options || {};
    const getNetworkSuccessFun = (resp) => {
        if ((resp.errorCode === "0" || resp.errorCode === 0 || resp.errorCode === "200" || resp.errorCode === 200) && resp.extraParam) {
            success && success(resp);
            return
        }
        getNetworkFailFun();
    }
    const getNetworkFailFun = (resp = {}) => {
       let result = getNetwork()
        if(result){
            success && success({
                errorCode: 0,
                msg: "获取网络状态成功",
                resultFrom: "cookie",
                extraParam: result
            });
        } else {
            fail && fail({
                errorCode: -1,
                msg: "获取网络状态失败"
            });
        }
    }
    Base.actionBridgeKey({
        name: "getNetworkState",
        success: getNetworkSuccessFun,
        fail: getNetworkFailFun,
    });
}
export default getNetworkState
