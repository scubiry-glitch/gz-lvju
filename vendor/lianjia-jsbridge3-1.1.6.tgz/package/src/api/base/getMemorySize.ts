import Base from "../../Base";

type IMemory = {
    sysUsedRAM?: string | number, // 系统已使用内存
    appUsedRAM?: string | number, // app已使用内存
    sysRAM?: string | number // 系统总内存
}

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: IMemory // 返回的额外参数
}

type IGetMemorySize = {
    success?: (res: Result) => void; // 成功回调
    fail?: (res: Result) => void; //   失败回调
    [key: string]: any;
}

const getMemorySize = (options?: IGetMemorySize) => {
    const { success, fail } = options || {};
    const successFun = (resp) => {
        if ((resp.errorCode === "0" || resp.errorCode === 0 || resp.errorCode === "200" || resp.errorCode === 200) && resp.extraParam) {
            try {
                if (typeof resp.extraParam === 'string') {
                    resp.extraParam = JSON.parse(resp.extraParam)
                }
                if(typeof resp.extraParam === 'object' && Object.keys(resp.extraParam).length > 0){
                    success && success({
                        errorCode: 0,
                        msg: "获取内存大小成功",
                        extraParam: resp.extraParam
                    });
                    return
                }
            } catch (e) {}
        }
        fail && fail({
            errorCode: -1,
            msg: "解析内存大小失败"
        });
    }
    Base.actionBridgeKey({
        name: "getMemorySize",
        timeout: 5000,
        success: successFun,
        fail,
    });
}
export default getMemorySize
