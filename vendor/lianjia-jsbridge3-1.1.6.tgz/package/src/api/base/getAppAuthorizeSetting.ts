/**
 * 获取权限
 */
import Base from "../../Base";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}

type getSettingI =  {
    authority: 'camera' | 'location' | 'photo' | string //要获取的权限
    needOpenSetting?: boolean //未授权是否自动打开授权弹窗
    success: (res: Result) => void; // 成功回调 完成后callBackName回调
    fail?: (res: Result) => void; //    失败回调
    [key: string]: any; // 其他参数
}

const getAppAuthorizeSetting = (options: getSettingI) => {
    const { authority, needOpenSetting =  false,   success, fail,  } = options;
    if(!authority){
        fail && fail({ errorCode: 1, msg: "权限名称不能为空" });
        return
    }
    const time = new Date().getTime()
    const functionName: any = `_BKBridgeV2_checkNativeAuthority_${time}`;
    if(typeof success === 'function'){
        (window as any)[functionName] = (resp) => {
            delete window[functionName]
            try {
                resp = JSON.parse(resp);
                if (resp.errorCode === "0" || resp.errorCode === 0 || resp.errorCode === "200" || resp.errorCode === 200) {
                    success && success(resp);
                } else {
                    fail && fail(resp);
                }
            } catch (e) {
                if ("console" in window) {
                    console.log("解析错误", e);
                }
                fail && fail({errorCode: 8, msg: "解析错误"});
            }
        }
    }
    Base.actionBridge2Key({
        name: needOpenSetting ? "checkNativeAuthority" : "getNativeAuthority",
        param: JSON.stringify({
            authority,
            callback: functionName
        }),
        success: ()=> {},
        fail,
    });
}
export default getAppAuthorizeSetting
