import Base from "../../Base";

type ICpu = {
    sysUsedCpu?: string | number, // 系统已使用cpu
    appUsedCpu?: string | number, // app已使用cpu
    [key: string]: any;
}

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: ICpu // 返回的额外参数
}

type IGetCpuInfo = {
    success?: (res: Result) => void; // 成功回调
    fail?: (res: Result) => void; //   失败回调
    [key: string]: any;
}

const getCpuInfo = (options?: IGetCpuInfo) => {
    const { success, fail } = options || {};
    const successFun = (resp) => {
        if ((resp.errorCode === "0" || resp.errorCode === 0 || resp.errorCode === "200" || resp.errorCode === 200) && resp.extraParam) {
            try {
                if (typeof resp.extraParam === 'string') {
                    resp.extraParam = JSON.parse(resp.extraParam)
                }
                if(typeof resp.extraParam === 'object' && Object.keys(resp.extraParam).length > 0){
                    success && success({
                        errorCode: 0,
                        msg: "获取cpu大小成功",
                        extraParam: resp.extraParam
                    });
                    return
                }
            } catch (e) {}
        }
        fail && fail({
            errorCode: -1,
            msg: "解析cpu大小失败"
        });
    }
    Base.actionBridgeKey({
        name: "getCpuInfo",
        timeout: 5000,
        success: successFun,
        fail,
    });
}
export default getCpuInfo
