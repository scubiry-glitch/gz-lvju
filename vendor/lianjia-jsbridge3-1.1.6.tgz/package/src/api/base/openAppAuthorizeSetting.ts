/**
 * 获取权限
 */
import Base from "../../Base";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}

type openSettingI = {
    authority:  'camera' | 'location' | 'photo' | string //要获取的权限
    success: (res: Result) => void; // 成功回调 完成后callBackName回调
    fail?: (res: Result) => void; //    失败回调
    [key: string]: any; // 其他参数
}

const openAppAuthorizeSetting = (options: openSettingI) => {
    const { success, fail } = options;
    const time = new Date().getTime()
    const functionName: any = `_BKBridgeV2_openAppAuthorizeSetting_${time}`;
    if(typeof success === 'function'){
        (window as any)[functionName] = (resp) => {
            delete window[functionName]
            try {
                resp = JSON.parse(resp);
                if (resp.errorCode === "0" || resp.errorCode === 0 || resp.errorCode === "200" || resp.errorCode === 200) {
                    success && success(resp);
                } else {
                    fail && fail(resp);
                }
            } catch (e) {
                if ("console" in window) {
                    console.log("解析错误", e);
                }
                fail && fail({errorCode: 8, msg: "解析错误"});
            }
        }
    }
    Base.actionBridge2Key({
        name: "jumpNativeSetting",
        param: JSON.stringify({
            callback: functionName
        }),
        success: ()=>{},
        fail,
    });
}
export default openAppAuthorizeSetting
