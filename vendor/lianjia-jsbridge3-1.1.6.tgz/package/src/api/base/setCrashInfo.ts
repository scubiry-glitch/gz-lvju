import Base from "../../Base";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: any // 返回的额外参数
}

type ISetCrashInfo = {
    text?: string; // 崩溃信息
    success?: (res: Result) => void; // 成功回调
    fail?: (res: Result) => void; //   失败回调
    [key: string]: any;
}

const setCrashInfo = (options?: string | ISetCrashInfo) => {
    let text = typeof options === 'string' && options || ''
    let success, fail
    if(typeof options === 'object'){
        text = options.text
        if(typeof options.success !== 'undefined'){
            success = options.success
        }
        if(typeof options.fail !== 'undefined'){
            fail = options.fail
        }
    }
    if(!text){
        console.warn('setCrashInfo方法必须传入text参数')
        fail && fail({
            errorCode: -1,
            msg: 'setCrashInfo方法必须传入text参数'
        })
        return
    }
    Base.actionBridgeKey({
        name: "setCrashInfo",
        param: text,
        success,
        fail,
    });
}
export default setCrashInfo
