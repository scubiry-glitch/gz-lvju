import Base from "../../Base";

const init = (config) => {
    Base.init(config)
}
const getStaticData = () => {
    return Base.getStaticData()
}
const getUserInfo = () => {
    let staticData = getStaticData()|| {}
    return staticData && staticData.userInfo
}
const getExtraData = () => {
    let staticData = getStaticData()|| {}
    return staticData && staticData.extraData
}
const getAppVersion = () => {
    let staticData = getStaticData()|| {}
    return staticData && staticData.appVersion
}
const getDeviceId = () => {
    let staticData = getStaticData()|| {}
    return staticData && staticData.deviceId
}
const getNetwork = () => {
    let staticData = getStaticData()|| {}
    return staticData && staticData.network
}
const getScheme = () => {
    let staticData = getStaticData()|| {}
    return staticData && staticData.scheme
}
const getSchemeLink = (url: string)=>{
    let scheme = getScheme()
    if(scheme){
        return `${scheme}://${url}`
    } else {
        return null
    }
}
const getAccessToken = () => {
    let staticData = getStaticData()|| {}
    return staticData && staticData.accessToken
}
const getDeviceInfo = ()=>{
    let staticData = getStaticData() || {}
    let deviceInfo = staticData.deviceInfo
    if(!deviceInfo){
        deviceInfo = staticData.mDeviceInfo
    }
    return deviceInfo
}
export {
    init,
    getSchemeLink,
    getStaticData,
    getExtraData,
    getUserInfo,
    getAccessToken,
    getAppVersion,
    getScheme,
    getNetwork,
    getDeviceId,
    getDeviceInfo
}
