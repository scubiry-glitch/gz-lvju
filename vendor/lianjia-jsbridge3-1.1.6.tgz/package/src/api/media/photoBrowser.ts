/**
 * 图片浏览器
 */
import Base from "../../Base";
import { getBase64Image } from "../../utils";

type Result = { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}

// 图片对象
type photoItem = {
    list: string[]; // 图片列表
    title: string; // 图片标题
}

// 图片浏览器
type photoBrowserI = {
    photos: photoItem[]; // 图片列表
    current: { // 当前图片
        group: string; // 图片组
        index: number; // 图片索引
    };
    showBar: boolean; //   是否显示导航
    anmation: boolean; // 是否显示动画
    position?: { // 当前图片的位置
        x: number; // 图片距离视窗窗口的左上定点的x位置
        y: number; // 图片距离视窗窗口的左上定点的y位置
        width: number; // 图片宽度
        height: number; // 图片高度
    };
    anmationBase64?: string; // 动画的base64
    success?: (res: Result) => void; // 成功回调
    fail?: (res: Result) => void; //    失败回调
    browserCallBack?: string // window方法名
    [key: string]: any; // 其他参数
}

const photoBrowser = async (options: photoBrowserI) => {
    const {
        photos,
        current,
        showBar,
        position,
        anmation,
        anmationBase64,
        browserCallBack,
        success,
        fail,
    } = options;
    let param: any = {photos, current, showBar};
    if (!(Array.isArray(photos) && photos.length)) {
        fail && fail({ errorCode: 1, msg: "photos不能为空" });
        return;
    }
    if (anmation) {
        param.position = position;
        param.anmationBase64 = anmationBase64;
        if (
            !param.anmationBase64 &&
            current.hasOwnProperty("group") &&
            current.hasOwnProperty("index")
        ) {
            let url =
                photos[current.group] &&
                photos[current.group]["list"] &&
                photos[current.group]["list"][current.index];
            if (url) {
                param.anmationBase64 = await getBase64Image(url);
            }
        }
    }
    if(browserCallBack){
        param.browserCallBack = browserCallBack
    }
    Base.actionBridgeKey({
        name: "photoBrowser",
        param: JSON.stringify(param),
        success,
        fail,
    });
}
export default photoBrowser
