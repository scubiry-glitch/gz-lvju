import { init, getStaticData,
    getExtraData,
    getUserInfo,
    getAccessToken,
    getAppVersion,
    getScheme,
    getNetwork,
    getDeviceId,
    getDeviceInfo,
    getSchemeLink
} from "./api/base/init"
import getNetworkState from "./api/base/getNetworkState"
import getAppAuthorizeSetting from "./api/base/getAppAuthorizeSetting"
import openAppAuthorizeSetting from "./api/base/openAppAuthorizeSetting"
import getMemorySize from "./api/base/getMemorySize";
import getCpuInfo from "./api/base/getCpuInfo";
import setCrashInfo from "./api/base/setCrashInfo";
import callAndBack from "./api/base/callAndBack"
import { navigateTo, navigateBack, redirectTo, closeWeb, startListenExit, stopListenExit } from "./api/route"
import photoBrowser from "./api/media/photoBrowser"
import requestData from "./api/net/requestData"
import sendLog from './api/net/sendLog'
import {
    appStorge,
    changeOrientation,
    gestureSideExitEnable,
    launchPhoneCall,
    location,
    scanCode,
    setSensorCallback,
    vibrate,
    screenshot,
    StartScreenshot,
    registerScreenShotMonitor,
    unRegisterScreenShotMonitor,
    changeWifiStatus,
    sendTextMessage,
    openBrowser,
    makePhoneCall,
    startListenGyroscope,
    stopListenGyroscope,
    startListenDeviceMotion,
    stopListenDeviceMotion
} from "./api/device"
import setNavItems from "./api/ui/setNavItems";
import setNavStyle from "./api/ui/setNavStyle"
import changeNaviBarItems from "./api/ui/changeNaviBarItems"
import setPageTitle from "./api/ui/setPageTitle"
import changeTitleBar from "./api/ui/changeTitleBar";
import setCloseBtnVisible from "./api/ui/setCloseBtnVisible"
import setRightButton from "./api/ui/setRightButton";
import changeTitleBarStyle from './api/ui/changeTitleBarStyle'
import downloadFile from "./api/file/downloadFile"
import chooseImage from './api/file/chooseImage'
import saveImage from "./api/file/saveImage"

import {getAPPEnv} from "./utils"

const JsBridgeV3 = {
    init,
    getSchemeLink,
    getStaticData,
    getExtraData,
    getUserInfo,
    getAccessToken,
    getAppVersion,
    getScheme,
    getNetwork,
    getDeviceId,
    getDeviceInfo,
    getAppAuthorizeSetting,
    openAppAuthorizeSetting,
    chooseImage,
    photoBrowser,
    requestData,
    scanCode,
    setNavStyle,
    getAPPEnv,
    changeNaviBarItems,
    appStorge,
    downloadFile,
    navigateTo,
    navigateBack,
    redirectTo,
    screenshot,
    StartScreenshot,
    saveImage,
    location,
    registerScreenShotMonitor,
    unRegisterScreenShotMonitor,
    setPageTitle,
    setCloseBtnVisible,
    changeOrientation,
    gestureSideExitEnable,
    setSensorCallback,
    vibrate,
    launchPhoneCall,
    changeWifiStatus,
    sendTextMessage,
    openBrowser,
    makePhoneCall,
    sendLog,
    changeTitleBar,
    closeWeb,
    setRightButton,
    changeTitleBarStyle,
    startListenGyroscope,
    stopListenGyroscope,
    startListenExit,
    stopListenExit,
    startListenDeviceMotion,
    stopListenDeviceMotion,
    setNavItems,
    getNetworkState,
    getMemorySize,
    setCrashInfo,
    callAndBack,
    getCpuInfo
}
if (typeof window === 'object') {
    (window as any).JsBridgeV3 = JsBridgeV3
}
export {
    init,
    getSchemeLink,
    getStaticData,
    getExtraData,
    getUserInfo,
    getAccessToken,
    getAppVersion,
    getScheme,
    getNetwork,
    getDeviceId,
    getDeviceInfo,
    callAndBack,
    getAppAuthorizeSetting,
    openAppAuthorizeSetting,
    chooseImage,
    photoBrowser,
    requestData,
    scanCode,
    setNavStyle,
    getAPPEnv,
    changeNaviBarItems,
    appStorge,
    downloadFile,
    navigateTo,
    navigateBack,
    redirectTo,
    screenshot,
    StartScreenshot,
    saveImage,
    location,
    registerScreenShotMonitor,
    unRegisterScreenShotMonitor,
    setPageTitle,
    setCloseBtnVisible,
    changeOrientation,
    gestureSideExitEnable,
    setSensorCallback,
    vibrate,
    launchPhoneCall,
    changeWifiStatus,
    sendTextMessage,
    openBrowser,
    makePhoneCall,
    sendLog,
    changeTitleBar,
    closeWeb,
    setRightButton,
    changeTitleBarStyle,
    startListenGyroscope,
    stopListenGyroscope,
    startListenExit,
    stopListenExit,
    startListenDeviceMotion,
    stopListenDeviceMotion,
    setNavItems,
    getNetworkState,
    getMemorySize,
    setCrashInfo,
    getCpuInfo
}
