import { getAPPEnv, getCookie, getUuid, setCookie } from "./utils";
import version from "./version";
interface Result { // 通用返回值
    errorCode: number | string // 0为成功，其他为失败
    msg: string // 返回的信息
    extraParam?: unknown // 返回的额外参数
}

export interface ParamsI { // 通用参数
    name?: string
    param?: string | number
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    timeout?: number
    withToken?: boolean
    [key: string]: any
}

export interface InitConfigI { // 初始化配置
    cookieDomain?: string //   cookie域名
    tokenKey?: string //  token的key
    ssidKey?: string //  ssid的key
    uuidKey?: string //  uuid的key
    udidKey?: string //  udid的key
    cityKey?: string //  city的key
    consoleLog?: boolean //  是否打印日志
    preventDomainSetting?: boolean //  是否阻止域名设置
    [key: string]: any
}

// 日志
export interface NativeLogI {
    summary?: string,
    detail?: any
}


class Jsbridge {
    config: InitConfigI = {};

    constructor() {
        if (typeof window !== "object") {
            return;
        }
        if(!(window as any).bridgeCallBack){
            (window as any).bridgeCallBack = (window as any).bridgeCallBack || function () {}
        }
        this.config = {
            cookieDomain: location.hostname.split(".").slice(-2).join("."),
            tokenKey: "lianjia_token",
            ssidKey: "lianjia_ssid",
            uuidKey: "lianjia_uuid",
            udidKey: "lianjia_udid",
            cityKey: "select_city",
            consoleLog: getAPPEnv().isApp,
            preventDomainSetting: false,
        }
        // 为了防止ua设置错误，这里都打印出来
        this.sendJSBridgeNativeLog(
            {
                summary: "ljBridgeSdkV3加载, " + window.location.href,
                detail: {
                    version,
                    ua: window.navigator.userAgent,
                    url: window.location.href,
                    cookie: document.cookie,
                },
            },
            "info"
        );
    }

    init(configs: InitConfigI = {}) {
        this.config = {
            ...this.config,
            ...configs,
        };
        if (!this.config.preventDomainSetting) {
            const staticData = this.getStaticData();
            const {ssid, uuid, udid, accessToken} = staticData;
            const {ssidKey, cookieDomain, uuidKey, udidKey, tokenKey} = this.config;
            ssid && setCookie(ssidKey, ssid, cookieDomain, 7);
            uuid && setCookie(uuidKey, uuid, cookieDomain, 7);
            udid && setCookie(udidKey, udid, cookieDomain, 7);
            accessToken && setCookie(tokenKey, accessToken, cookieDomain, 7);
        }
    }

    getStaticData() {
        let bridgeStaticData: any;
        try {
            bridgeStaticData = getCookie("_staticData") || getCookie("staticData");
            const win: any = window;
            if(bridgeStaticData){
                bridgeStaticData = decodeURIComponent(bridgeStaticData)
            }
            if (!bridgeStaticData && win["HybridBridgeLJ"] && typeof win["HybridBridgeLJ"]["_getStaticData"] === "function") {
                bridgeStaticData = win["HybridBridgeLJ"]["_getStaticData"]();
            }
            if(bridgeStaticData){
                bridgeStaticData = JSON.parse(bridgeStaticData)
            }
        } catch (e) {
        }
        if (!bridgeStaticData) {
            bridgeStaticData = {};
        }
        return bridgeStaticData;
    }

    actionBridgeKey({
                        name,
                        param = "",
                        timeout,
                        success = () => {
                        },
                        fail = () => {
                        },
                    }: ParamsI) {
        let cancelId: any;
        if (!name || (typeof name).toLowerCase() !== "string") {
            fail && fail({errorCode: 2, msg: "name must be string"});
            return;
        }
        if (param && (typeof param).toLowerCase() !== "string") {
            fail && fail({errorCode: 2, msg: "param must be string"});
            return;
        }
        const time = new Date().getTime()
        const uuid = getUuid()
        const functionName: any = `_BKBridgeV3_${name}_${time}_${uuid}`;
        this.sendJSBridgeNativeLog({
            summary: `actionBridgeKey: ${name} param:${param} functionName: ${functionName}`,
        });

        if (typeof timeout === "number") {
            cancelId = setTimeout(() => {
                delete window[functionName];
                fail && fail({errorCode: 7, msg: "timeout"});
            }, timeout);
        }
        (window as any)[functionName] = (resp: any) => {
            cancelId && clearTimeout(cancelId);
            delete window[functionName];
            if (resp) {
                try {
                    resp = JSON.parse(resp);
                    if (resp.errorCode === "0" || resp.errorCode === 0) {
                        success && success(resp);
                    } else {
                        fail && fail(resp);
                    }
                } catch (e) {
                    if ("console" in window) {
                        console.log("解析错误", e);
                    }
                    fail && fail({errorCode: 8, msg: "解析错误"});
                }
            } else {
                if ("console" in window) {
                    console.log("解析错误, 无resp值");
                }
                fail && fail({errorCode: 8, msg: "解析错误"});
            }
        };
        try {
            if (
                (window as any).BKBridgeV3 &&
                typeof (window as any).BKBridgeV3[name] === "function"
            ) {
                (window as any).BKBridgeV3[name](param, functionName);
            } else {
                (window as any).webkit.messageHandlers.BKBridgeV3.postMessage(
                    JSON.stringify({
                        name,
                        param,
                        callback: functionName,
                    })
                );
            }
        } catch (e) {
            if ("console" in window) {
                console.log("方法不存在" ,e);
            }
            fail && fail({errorCode: 8, msg: "方法不存在"});
        }
    }

    actionBridge2Key({
                         name,
                         param = "",
                         withToken = false,
                         success = () => {
                         },
                         fail = () => {
                         },
                     }: ParamsI) {
        if (!name || (typeof name).toLowerCase() !== "string") {
            fail && fail({errorCode: 2, msg: "name must be string"});
            return;
        }
        if (param && (typeof param).toLowerCase() !== "string") {
            fail && fail({errorCode: 2, msg: "param must be string"});
            return;
        }
        this.sendJSBridgeNativeLog({
            summary: `actionBridge2Key: ${name} param:${param}`,
        });
        try {
            let token = 'bd2de216518cc142d893eb61a6657272'
            const bridgeKey = 'HybridBridgeLJ';
            const bridgeNewKey = 'HybridBridgeLJ_EXTENSION';
            if ((window as any)[bridgeNewKey] &&
                typeof (window as any)[bridgeNewKey][name] === "function") {
                if(withToken){
                    (window as any)[bridgeNewKey][name](param, token);
                } else {
                    (window as any)[bridgeNewKey][name](param)
                }
            } else if ((window as any)[bridgeKey] &&
                typeof (window as any)[bridgeKey][name] === "function") {
                if(withToken){
                    (window as any)[bridgeKey][name](param, token);
                } else {
                    (window as any)[bridgeKey][name](param)
                }
            } else {
                let params: any = {
                    type: name,
                    param: param,
                    isNew: 1,
                }
                if(withToken){
                    params.token = token
                }
                (window as any).webkit.messageHandlers.lianjia.postMessage(JSON.stringify(params));
            }
            success && success({ errorCode: 0, msg: '调用成功' })
        } catch (e) {
            if ("console" in window) {
                console.log("方法不存在", e);
            }
            fail && fail({errorCode: 8, msg: "方法不存在"});
        }
    }

    sendJSBridgeNativeLog(params: NativeLogI = {}, type = "") {
        try {
            let summary = "ljBridgeSdk信息上报：";
            let detail = {};
            if (
                params &&
                params.summary &&
                (typeof params.summary).toLocaleString() === "string"
            ) {
                summary = params.summary;
            }
            if (
                params &&
                params.detail &&
                (typeof params.detail).toLocaleString() === "object"
            ) {
                try {
                    detail = JSON.parse(JSON.stringify(params.detail));
                } catch (e) {
                }
                detail = params.detail;
            }
            if ("console" in window && (this.config.consoleLog || type)) {
                if (type === "warn" && console.warn) {
                    console.warn(
                        "ljBridgeSdk warn:" + summary + ",detail: " + JSON.stringify(detail)
                    );
                } else if (type === "error" && console.error) {
                    console.error(
                        "ljBridgeSdk error:" +
                        summary +
                        ",detail: " +
                        JSON.stringify(detail)
                    );
                } else {
                    console.log(
                        "ljBridgeSdk log:" + summary + ",detail: " + JSON.stringify(detail)
                    );
                }
            }
            const win = window as any;
            if (
                win.BKNativeLog &&
                win.BKNativeLog.log &&
                typeof win.BKNativeLog.log === "function"
            ) {
                win.BKNativeLog.log(
                    JSON.stringify({
                        logLevel: 1,
                        logType: 1,
                        subType: "ljBridgeSdk",
                        summary: summary,
                        params: detail,
                    })
                );
            }
        } catch (e) {
            if ("console" in window) {
                console.log("window.BKNativeLog.log error", e);
            }
        }
    }
}

const JSBridge = new Jsbridge();
export default JSBridge
