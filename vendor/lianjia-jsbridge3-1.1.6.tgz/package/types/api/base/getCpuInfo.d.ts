type ICpu = {
    sysUsedCpu?: string | number;
    appUsedCpu?: string | number;
    [key: string]: any;
};
type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: ICpu;
};
type IGetCpuInfo = {
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const getCpuInfo: (options?: IGetCpuInfo) => void;
export default getCpuInfo;
