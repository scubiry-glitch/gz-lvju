type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: any;
};
type ISetCrashInfo = {
    text?: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const setCrashInfo: (options?: string | ISetCrashInfo) => void;
export default setCrashInfo;
