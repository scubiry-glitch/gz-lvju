type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type openSettingI = {
    authority: 'camera' | 'location' | 'photo' | string;
    success: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const openAppAuthorizeSetting: (options: openSettingI) => void;
export default openAppAuthorizeSetting;
