type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type getSettingI = {
    authority: 'camera' | 'location' | 'photo' | string;
    needOpenSetting?: boolean;
    success: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const getAppAuthorizeSetting: (options: getSettingI) => void;
export default getAppAuthorizeSetting;
