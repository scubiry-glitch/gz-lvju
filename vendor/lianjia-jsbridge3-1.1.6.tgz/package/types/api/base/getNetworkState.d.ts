type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: "WIFI" | "WWAN" | "NOTREACH" | "UNKNOW" | unknown;
    resultFrom?: string;
};
type IGetNetworkState = {
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const getNetworkState: (options?: IGetNetworkState) => void;
export default getNetworkState;
