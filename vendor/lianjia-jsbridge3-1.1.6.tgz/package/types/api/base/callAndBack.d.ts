type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type callAndBackI = {
    actionUrl: string;
    functionName: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const callAndBack: (options: callAndBackI) => void;
export default callAndBack;
