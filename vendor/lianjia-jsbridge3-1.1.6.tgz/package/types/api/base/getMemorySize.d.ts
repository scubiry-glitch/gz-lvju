type IMemory = {
    sysUsedRAM?: string | number;
    appUsedRAM?: string | number;
    sysRAM?: string | number;
};
type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: IMemory;
};
type IGetMemorySize = {
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const getMemorySize: (options?: IGetMemorySize) => void;
export default getMemorySize;
