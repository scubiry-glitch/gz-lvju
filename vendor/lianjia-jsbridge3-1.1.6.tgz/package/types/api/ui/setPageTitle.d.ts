type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type setPageTitleI = {
    title: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const setPageTitle: (options: string | setPageTitleI) => void;
export default setPageTitle;
