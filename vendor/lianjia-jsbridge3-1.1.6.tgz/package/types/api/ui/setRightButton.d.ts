type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type RightButtonItem = {
    name?: string;
    clickUrl?: string;
    imageUrl?: string;
    textHexColor?: string;
    callBackFunction?: string;
    [key: string]: any;
};
type setRightButtonI = {
    buttons: RightButtonItem[];
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const setRightButton: (options: setRightButtonI) => void;
export default setRightButton;
