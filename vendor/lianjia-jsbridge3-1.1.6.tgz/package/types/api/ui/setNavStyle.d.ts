export declare enum NavStyEnum {
    default = "0",
    hiddenNavBar = "1",
    hiddenBar = "2",
    Immersive = "3"
}
export declare enum graSLightEnum {
    black = "0",
    white = "1",
    off = "-1"
}
export declare enum sLightEnum {
    black = "0",
    white = "1"
}
export declare enum graSTHideEnum {
    hide = "1",
    show = "0"
}
type NavSty = 0 | 1 | 2 | 3 | '0' | '1' | '2' | '3' | NavStyEnum;
type IgraSLight = -1 | 0 | 1 | '-1' | '0' | '1' | graSLightEnum;
type IsLight = 0 | 1 | '0' | '1' | sLightEnum | string;
type graSTHide = 0 | 1 | '0' | '1' | graSTHideEnum | string;
type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type ISetNavStyle = {
    navSty: NavSty;
    graBColor?: string;
    graHeight?: number | string;
    graBTColor?: string;
    graETColor?: string;
    graSLight?: IgraSLight;
    graSTHide?: graSTHide;
    sLight?: IsLight;
    endBgColor?: string;
    height?: number | string;
    startColor?: string;
    endColor?: string;
    light?: IgraSLight;
    hideTitle?: graSTHide;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const setNavStyle: (options: ISetNavStyle) => void;
export default setNavStyle;
