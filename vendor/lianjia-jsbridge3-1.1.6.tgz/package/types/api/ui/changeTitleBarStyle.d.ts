type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type changeTitleBarStyleI = {
    hidden: '0' | '1';
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const changeTitleBarStyle: (options: changeTitleBarStyleI) => void;
export default changeTitleBarStyle;
