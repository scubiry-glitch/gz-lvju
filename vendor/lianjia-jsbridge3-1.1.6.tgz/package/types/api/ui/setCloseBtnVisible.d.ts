type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type setCloseBtnVisibleI = {
    visible: 0 | 1;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const setCloseBtnVisible: (options: setCloseBtnVisibleI) => void;
export default setCloseBtnVisible;
