type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type IBarItems = {
    icon: string;
    key: string;
    callback?: string;
    width?: number;
    height?: number;
};
type IPosition = "left" | "right" | "center" | "";
type IBarTitle = {
    icon: string | string[];
    position?: IPosition | IPosition[];
    type?: string;
    callback?: string;
};
type IBarTitleStartEnd = {
    start: {
        icon: string;
        position?: IPosition;
        type?: string;
        callback?: string;
    };
    end: {
        icon: string;
        position?: IPosition;
        type?: string;
        callback?: string;
    };
};
type IButtonItem = {
    start: IBarItems[];
    end: IBarItems[];
};
type ISetNavItems = {
    leftButtons?: IButtonItem | IBarItems[];
    rightButtons?: IButtonItem | IBarItems[];
    barTitle?: IBarTitle | IBarTitleStartEnd;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    changeCallback?: (status: "start" | "end" | string) => void;
    [key: string]: any;
};
declare const setNavItems: (options: ISetNavItems) => void;
export default setNavItems;
