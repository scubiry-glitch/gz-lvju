type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type ButtonItem = {
    imageUrl: string;
    callback: string;
    width?: number | string;
    height?: number | string;
};
type barTitleI = {
    title?: string;
    imageUrl?: string;
    imageWidth?: number | string;
    imageHeight?: number | string;
};
type changeNaviBarItemsI = {
    leftButtons?: ButtonItem[];
    rightButtons?: ButtonItem[];
    barTitle?: barTitleI;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const changeNaviBarItems: (options: changeNaviBarItemsI) => void;
export default changeNaviBarItems;
