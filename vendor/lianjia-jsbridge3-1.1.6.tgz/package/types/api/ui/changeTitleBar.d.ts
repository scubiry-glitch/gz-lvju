type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type changeTitleBarI = {
    name: string;
    textColor?: string;
    backgroundColor?: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const changeTitleBar: (options: changeTitleBarI) => void;
export default changeTitleBar;
