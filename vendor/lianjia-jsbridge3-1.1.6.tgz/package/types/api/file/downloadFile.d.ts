type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type downloadFileI = {
    url: string;
    isShowShare?: 0 | 1;
    md5?: string;
    shareName?: string;
    progressCallBack?: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const downloadFile: (options: downloadFileI) => void;
export default downloadFile;
