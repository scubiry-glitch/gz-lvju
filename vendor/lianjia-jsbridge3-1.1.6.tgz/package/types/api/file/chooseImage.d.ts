type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type ContentType = "text/html" | "text/plain" | "multipart/form-data" | "application/json" | "application/x-www-form-urlencoded" | "application/octet-stream" | string;
type Headers = {
    "Content-Type"?: ContentType;
    [key: string]: any;
};
type chooseImageI = {
    count?: number;
    accept?: 'image/*' | 'video/*' | 'audio/*' | string;
    action: string;
    confirmText?: string;
    headers?: Headers;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    sourceType?: 'album' | 'camera';
    saveAlbum?: 0 | 1;
    allowOriginPhoto?: boolean;
    [key: string]: any;
};
declare const chooseImage: (options: chooseImageI) => void;
export default chooseImage;
