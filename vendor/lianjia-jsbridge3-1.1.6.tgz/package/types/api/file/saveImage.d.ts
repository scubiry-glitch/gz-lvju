type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type saveImageI = {
    image: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const saveImage: (options: saveImageI) => void;
export default saveImage;
