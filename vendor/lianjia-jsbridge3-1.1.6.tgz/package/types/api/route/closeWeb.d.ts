type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type closeWebI = {
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const closeWeb: (options?: closeWebI) => void;
export default closeWeb;
