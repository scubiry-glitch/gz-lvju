type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
export type openUrlI = {
    url: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    forceUseOld?: boolean;
    [key: string]: any;
};
declare const navigateTo: (options: openUrlI) => void;
export default navigateTo;
