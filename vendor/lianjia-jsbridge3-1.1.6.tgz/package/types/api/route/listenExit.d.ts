type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: any;
};
type IListenerType = 'btnClose' | 'btnReturn' | 'swipeBack';
type IListenExit = {
    h5Exit?: boolean;
    listenerFun: string;
    type?: IListenerType[];
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
export declare const startListenExit: (options: IListenExit) => void;
export declare const stopListenExit: (options?: {
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
}) => void;
declare const _default: {
    startListenExit: (options: IListenExit) => void;
    stopListenExit: (options?: {
        success?: (res: Result) => void;
        fail?: (res: Result) => void;
    }) => void;
};
export default _default;
