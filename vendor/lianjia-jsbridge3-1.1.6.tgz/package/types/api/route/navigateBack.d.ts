type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type closeToI = {
    topTo: number;
    secondTo: number;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const navigateBack: (options: closeToI) => void;
export default navigateBack;
