type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
export type openUrlI = {
    url: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const redirectTo: (options: openUrlI) => void;
export default redirectTo;
