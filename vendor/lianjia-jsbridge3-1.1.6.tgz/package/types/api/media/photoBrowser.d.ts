type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type photoItem = {
    list: string[];
    title: string;
};
type photoBrowserI = {
    photos: photoItem[];
    current: {
        group: string;
        index: number;
    };
    showBar: boolean;
    anmation: boolean;
    position?: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
    anmationBase64?: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    browserCallBack?: string;
    [key: string]: any;
};
declare const photoBrowser: (options: photoBrowserI) => Promise<void>;
export default photoBrowser;
