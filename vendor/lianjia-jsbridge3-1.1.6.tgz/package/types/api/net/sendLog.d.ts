export interface sendLogI {
    logLevel?: string;
    logType?: string;
    subType?: string;
    summary?: string;
    detail?: any;
}
declare const sendLog: (params: sendLogI) => void;
export default sendLog;
