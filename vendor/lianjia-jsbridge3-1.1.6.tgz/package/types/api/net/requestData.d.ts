type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type ContentType = "text/html" | "text/plain" | "multipart/form-data" | "application/json" | "application/x-www-form-urlencoded" | "application/octet-stream" | string;
type Headers = {
    "Content-Type"?: ContentType;
    [key: string]: any;
};
type methodI = "get" | "post" | string;
type requestDataI = {
    url: string;
    method?: methodI;
    params?: object;
    headers?: Headers;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    timeout: number;
    [key: string]: any;
};
declare const requestData: (options: requestDataI) => void;
export default requestData;
