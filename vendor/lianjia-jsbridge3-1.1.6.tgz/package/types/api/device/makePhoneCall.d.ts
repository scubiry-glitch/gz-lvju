type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type makePhoneCallI = {
    phoneNumber: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const makePhoneCall: (options: makePhoneCallI) => void;
export default makePhoneCall;
