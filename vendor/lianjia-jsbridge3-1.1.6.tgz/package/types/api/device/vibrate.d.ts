type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type vibrateI = {
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const vibrate: (options: vibrateI) => void;
export default vibrate;
