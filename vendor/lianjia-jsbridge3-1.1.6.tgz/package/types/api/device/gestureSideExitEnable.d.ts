type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
export declare enum ExitEnable {
    unenable = "0",
    enable = "1"
}
interface gestureSideExitEnableI {
    enable: '0' | '1' | ExitEnable;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
}
declare const gestureSideExitEnable: (options: gestureSideExitEnableI) => void;
export default gestureSideExitEnable;
