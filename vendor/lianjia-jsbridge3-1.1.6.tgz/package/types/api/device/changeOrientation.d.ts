type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
export declare enum Orientation {
    vertical = "1",
    Landscape = "0"
}
type changeOrientationI = {
    orientation: '0' | '1' | Orientation;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const changeOrientation: (options: changeOrientationI) => void;
export default changeOrientation;
