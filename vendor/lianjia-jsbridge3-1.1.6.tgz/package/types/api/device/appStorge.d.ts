type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: any;
};
export declare enum storeTypeI {
    Memory = 0,
    Disk = 1
}
export declare enum secureTypeI {
    share = 0,
    Private = 1
}
type storgeI = {
    storeType?: 0 | 1 | storeTypeI;
    secureType?: 0 | 1 | secureTypeI;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const appStorge: {
    set: (key: string, value: any, options?: storgeI) => void;
    remove: (key: string, options?: storgeI) => void;
    get: (key: string, options?: storgeI) => void;
};
export default appStorge;
