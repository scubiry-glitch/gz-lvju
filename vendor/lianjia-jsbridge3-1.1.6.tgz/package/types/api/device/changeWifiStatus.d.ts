type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type changeWifiStatusI = {
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const changeWifiStatus: (options: changeWifiStatusI) => void;
export default changeWifiStatus;
