type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: any;
};
export declare enum IGyroscopeIntervalType {
    FASTEST = 1,
    GAME = 2,
    DELAY_UI = 3,
    NORMAL = 4
}
type IStartGyroscope = {
    intervalType?: 1 | 2 | 3 | 4 | '1' | '2' | '3' | '4' | IGyroscopeIntervalType;
    listenerFun: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
export declare const startListenGyroscope: (options: IStartGyroscope) => void;
export declare const stopListenGyroscope: (options: {
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
}) => void;
declare const _default: {
    startListenGyroscope: (options: IStartGyroscope) => void;
    stopListenGyroscope: (options: {
        success?: (res: Result) => void;
        fail?: (res: Result) => void;
    }) => void;
};
export default _default;
