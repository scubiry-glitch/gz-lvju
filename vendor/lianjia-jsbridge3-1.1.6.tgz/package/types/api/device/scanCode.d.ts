type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type scanCodeI = {
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    onlyScanCode?: boolean;
    [key: string]: any;
};
declare const scanCode: (options?: scanCodeI) => void;
export default scanCode;
