type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type launchPhoneCallI = {
    phoneNumber: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const launchPhoneCall: (options: launchPhoneCallI) => void;
export default launchPhoneCall;
