type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type screenshotI = {
    startLeft?: number;
    startTop?: number;
    width?: number;
    height?: number;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
interface screenshotNewViewI {
    url?: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
}
interface MonitorI {
    callback?: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
}
export declare const screenshot: (options?: screenshotI & screenshotNewViewI) => void;
export declare const StartScreenshot: (options?: screenshotI) => void;
export declare const registerScreenShotMonitor: (options: MonitorI) => void;
export declare const unRegisterScreenShotMonitor: (options: MonitorI) => void;
export {};
