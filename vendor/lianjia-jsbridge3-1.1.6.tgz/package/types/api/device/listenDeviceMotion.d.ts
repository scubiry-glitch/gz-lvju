type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: any;
};
export declare enum IIntervalType {
    FASTEST = 1,
    GAME = 2,
    DELAY_UI = 3,
    NORMAL = 4
}
type IStartListenDeviceMotion = {
    intervalType?: 1 | 2 | 3 | 4 | '1' | '2' | '3' | '4' | IIntervalType;
    listenerFun: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
export declare const startListenDeviceMotion: (options: IStartListenDeviceMotion) => void;
export declare const stopListenDeviceMotion: (options: {
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
}) => void;
declare const _default: {
    startListenDeviceMotion: (options: IStartListenDeviceMotion) => void;
    stopListenDeviceMotion: (options: {
        success?: (res: Result) => void;
        fail?: (res: Result) => void;
    }) => void;
};
export default _default;
