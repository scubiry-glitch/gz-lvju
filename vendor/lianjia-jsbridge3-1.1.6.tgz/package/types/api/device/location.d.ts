type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
export declare enum isfastI {
    isfast = 1,
    nofast = 0
}
type getLocationI = {
    isfast: 0 | 1 | isfastI;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const getLocation: (options: getLocationI) => void;
export default getLocation;
