type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type setSensorCallbackI = {
    sensor_type: "shake";
    jsFunction: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const setSensorCallback: (options: setSensorCallbackI) => void;
export default setSensorCallback;
