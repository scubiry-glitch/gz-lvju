type Result = {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
};
type openBrowserI = {
    url: string;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    [key: string]: any;
};
declare const openBrowser: (options: string | openBrowserI) => void;
export default openBrowser;
