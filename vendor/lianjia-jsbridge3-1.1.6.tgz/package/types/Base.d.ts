interface Result {
    errorCode: number | string;
    msg: string;
    extraParam?: unknown;
}
export interface ParamsI {
    name?: string;
    param?: string | number;
    success?: (res: Result) => void;
    fail?: (res: Result) => void;
    timeout?: number;
    withToken?: boolean;
    [key: string]: any;
}
export interface InitConfigI {
    cookieDomain?: string;
    tokenKey?: string;
    ssidKey?: string;
    uuidKey?: string;
    udidKey?: string;
    cityKey?: string;
    consoleLog?: boolean;
    preventDomainSetting?: boolean;
    [key: string]: any;
}
export interface NativeLogI {
    summary?: string;
    detail?: any;
}
declare class Jsbridge {
    config: InitConfigI;
    constructor();
    init(configs?: InitConfigI): void;
    getStaticData(): any;
    actionBridgeKey({ name, param, timeout, success, fail, }: ParamsI): void;
    actionBridge2Key({ name, param, withToken, success, fail, }: ParamsI): void;
    sendJSBridgeNativeLog(params?: NativeLogI, type?: string): void;
}
declare const JSBridge: Jsbridge;
export default JSBridge;
